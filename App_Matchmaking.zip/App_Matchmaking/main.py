from flask import Flask, render_template, url_for, redirect, request
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from form import mahasiswaform

app = Flask(__name__)
bcrypt = Bcrypt(app)

posts = [
    {
        'author': 'Corey Schafer',
        'title': 'Blog Post 1',
        'content': 'First post content',
        'date posted': 'April 20, 2018'
    },
    {
        'author': 'Jane Doe',
        'title': 'Blog Post 2',
        'content': 'Second post content',
        'date posted': 'April 21, 2018'
    }
]

@app.route('/')
@app.route('/')
def baru():
    return render_template('baru.html')

@app.route('/', methods=['post'])
def getvalue():
    kecerdasan = request.form['Kecerdasan']
    daya_tangkap = request.form['Daya Tangkap']
    logika_berpikir = request.form['Logika Berpikir']
    analisa = request.form['Analisa']
    fleksibilitas_berpikir = request.form['Fleksibilitas Berpikir']
    kecerdasan_verbal = request.form['Kecerdasan Verbal']
    pengolahan_data_angka = request.form['Pengolahan Data Angka']
    pemecahan_masalah = request.form['Pemecahan Masalah']
    produktivitas_kerja = request.form['Produktivitas Kerja']
    motivasi_kerja = request.form['Motivasi Kerja']
    perencanaan = request.form['Perencanaan']
    pengendalian = request.form['Pengendalian']
    daya_tahan_kerja = request.form['Daya Tahan Kerja']
    konsentrasi = request.form['Konsentrasi']
    inisiatif = request.form['Inisiatif']
    stabilitas_emosi = request.form['Stabilitas Emosi']
    kerja_sama = request.form['Kerja Sama']
    penyesuaian_diri = request.form['Penyesuaian Diri']

    Mandiri = ["Baik", "Baik", "Kurang", "Baik", "Kurang", "Baik", "Kurang", "Kurang", "Baik", "Kurang", "Kurang"]
    Diskusi = ["Kurang", "Kurang", "Baik", "Kurang", "Baik", "Kurang", "Baik", "Baik", "Kurang", "Baik", "Baik"]
    mandi = 0
    disku = 0
    juman = 0
    judis = 0

    if kecerdasan == Mandiri[0]:
        mandi = mandi + 1
    if analisa == Mandiri[1]:
        mandi = mandi + 1
    if kecerdasan_verbal == Mandiri[2]:
        mandi = mandi + 1
    if pengolahan_data_angka == Mandiri[3]:
        mandi = mandi + 1
    if produktivitas_kerja == Mandiri[4]:
        mandi = mandi + 1
    if motivasi_kerja == Mandiri[5]:
        mandi = mandi + 1
    if pengendalian == Mandiri[6]:
        mandi = mandi + 1
    if konsentrasi == Mandiri[7]:
        mandi = mandi + 1
    if stabilitas_emosi == Mandiri[8]:
        mandi = mandi + 1
    if kerja_sama == Mandiri[9]:
        mandi = mandi + 1
    if penyesuaian_diri == Mandiri[10]:
        mandi = mandi + 1
    if kecerdasan == Diskusi[0]:
        disku = disku + 1
    if analisa == Diskusi[1]:
        disku = disku + 1
    if kecerdasan_verbal == Diskusi[2]:
        disku = disku + 1
    if pengolahan_data_angka == Diskusi[3]:
        disku = disku + 1
    if produktivitas_kerja == Diskusi[4]:
        disku = disku + 1
    if motivasi_kerja == Diskusi[5]:
        disku = disku + 1
    if pengendalian == Diskusi[6]:
        disku = disku + 1
    if konsentrasi == Diskusi[7]:
        disku = disku + 1
    if stabilitas_emosi == Diskusi[8]:
        disku = disku + 1
    if kerja_sama == Diskusi[9]:
        disku = disku + 1
    if penyesuaian_diri == Diskusi[10]:
        disku = disku + 1

    juman = mandi/11 * 100
    judis = disku/11 * 100
    return render_template('pass.html', juman=juman, judis=judis, kecerdasan=kecerdasan, daya_tangkap=daya_tangkap,
                           logika_berpikir=logika_berpikir, analisa=analisa,
                           fleksibilitas_berpikir=fleksibilitas_berpikir, kecerdasan_verbal=kecerdasan_verbal,
                           pengolahan_data_angka=pengolahan_data_angka, pemecahan_masalah=pemecahan_masalah,
                           produktivitas_kerja=produktivitas_kerja, motivasi_kerja=motivasi_kerja,
                           perencanaan=perencanaan, pengendalian=pengendalian, daya_tahan_kerja=daya_tahan_kerja,
                           konsentrasi=konsentrasi, inisiatif=inisiatif, stabilitas_emosi=stabilitas_emosi,
                           kerja_sama=kerja_sama, penyesuaian_diri=penyesuaian_diri)


if __name__ == "__main__":
    app.run(debug=True)