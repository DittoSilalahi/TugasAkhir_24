from flask import Flask, render_template, url_for, redirect, request
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from form import mahasiswaform

posts = [
    {
        'author': 'Corey Schafer',
        'title': 'Blog Post 1',
        'content': 'First post content',
        'date posted': 'April 20, 2018'
    },
    {
        'author': 'Jane Doe',
        'title': 'Blog Post 2',
        'content': 'Second post content',
        'date posted': 'April 21, 2018'
    }
]

app = Flask(__name__)
app.config['SECRET_KEY'] = '870f94cd87f840f55e7c9e81ba1d6bba'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///maha.db'
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)

@app.route('/')
@app.route('/home')
def home():
    return render_template('home.html', posts=posts)

@app.route('/about')
def about():
    return "<h1>About Page</h1>"

class pengguna(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    kecerdasan = db.Column(db.String(6), nullable=False)
    analisa = db.Column(db.String(6), nullable=False)
    kecerdasan_verbal = db.Column(db.String(6), nullable=False)
    pengolahan_data_angka = db.Column(db.String(6), nullable=False)
    produktivitas_kerja = db.Column(db.String(6), nullable=False)
    motivasi_kerja = db.Column(db.String(6), nullable=False)
    pengendalian = db.Column(db.String(6), nullable=False)
    konsentrasi = db.Column(db.String(6), nullable=False)
    stabilitas_emosi = db.Column(db.String(6), nullable=False)
    kerja_sama = db.Column(db.String(6), nullable=False)
    penyesuaian_diri = db.Column(db.String(6), nullable=False)

    def __repr__(self):
        return f"User('{self.kecerdasan}', '{self.analisa}', '{self.kecerdasan_verbal}', '{self.pengolahan_data_angka}', '{self.produktivitas_kerja}', '{self.motivasi_kerja}', '{self.pengendalian}', '{self.konsentrasi}', '{self.stabilitas_emosi}', '{self.kerja_sama}', '{self.penyesuaian_diri}')"

@app.route("/<user>")
def index(user=None):
    return render_template("user.html", user=user)

@app.route('/send', methods=['GET', 'POST'])
def send():
    if request.method == 'POST':
        age = request.form['age']
        if request.form['age'] < 18:
            return render_template('age.html', age="belum cukup umur")
        else:
            return render_template('age.html', age=age)
    return render_template('index.html')

@app.route("/shopping")
def shopping():
    food = ["Cheese", "Tuna", "Beef", "Toothpaste"]
    return render_template("shopping.html", food=food)

@app.route("/mahasiswa", methods=['GET', 'POST'])
def mahasiswa():
    Mandiri = 0
    Diskusi = 0
    form = mahasiswaform()
    if form.validate_on_submit():
        if form.kecerdasan.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.analisa.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.kecerdasan_verbal.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.pengolahan_data_angka.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.produktivitas_kerja.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.motivasi_kerja.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.pengendalian.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.konsentrasi.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.stabilitas_emosi.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.kerja_sama.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.penyesuaian_diri.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        bobot_mandiri = Mandiri/11 * 100
        bobot_diskusi = Diskusi/11 * 100

        final_bobot_mandiri = "Mandiri = " + str(bobot_mandiri) + " %"
        final_bobot_diskusi = "Diskusi = " + str(bobot_diskusi) + " %"

        if request.method == 'POST':
            final_bobot_mandiri = request.form['final_bobot_mandiri']
            final_bobot_diskusi = request.form['final_bobot_diskusi']

            return redirect(url_for('metodebelajar.html', title="Metode Belajar", final_bobot_mandiri=final_bobot_mandiri, final_bobot_diskusi=final_bobot_diskusi))

    return render_template('mhs.html', title="mahasiswa", form=form)

if __name__ == "__main__":
    app.run(debug=True)