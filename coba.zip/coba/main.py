from flask import Flask, render_template, url_for, redirect, request
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from form import mahasiswaform

app = Flask(__name__)
app.config['SECRET_KEY'] = '870f94cd87f840f55e7c9e81ba1d6bba'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///maha.db'
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)

posts = [
    {
        'author': 'Corey Schafer',
        'title': 'Blog Post 1',
        'content': 'First post content',
        'date posted': 'April 20, 2018'
    },
    {
        'author': 'Jane Doe',
        'title': 'Blog Post 2',
        'content': 'Second post content',
        'date posted': 'April 21, 2018'
    }
]

@app.route('/')
@app.route('/')
def baru():
    return render_template('baru.html')

@app.route('/', methods=['post'])
def getvalue():
    kecerdasan = request.form['Kecerdasan']
    daya_tangkap = request.form['Daya Tangkap']
    logika_berpikir = request.form['Logika Berpikir']
    analisa = request.form['Analisa']
    fleksibilitas_berpikir = request.form['Fleksibilitas Berpikir']
    kecerdasan_verbal = request.form['Kecerdasan Verbal']
    pengolahan_data_angka = request.form['Pengolahan Data Angka']
    pemecahan_masalah = request.form['Pemecahan Masalah']
    produktivitas_kerja = request.form['Produktivitas Kerja']
    motivasi_kerja = request.form['Motivasi Kerja']
    perencanaan = request.form['Perencanaan']
    pengendalian = request.form['Pengendalian']
    daya_tahan_kerja = request.form['Daya Tahan Kerja']
    konsentrasi = request.form['Konsentrasi']
    inisiatif = request.form['Inisiatif']
    stabilitas_emosi = request.form['Stabilitas Emosi']
    kerja_sama = request.form['Kerja Sama']
    penyesuaian_diri = request.form['Penyesuaian Diri']

    Mandiri = ["Baik", "Baik", "Kurang", "Baik", "Kurang", "Baik", "Kurang", "Kurang", "Baik", "Kurang", "Kurang"]
    Diskusi = ["Kurang", "Kurang", "Baik", "Kurang", "Baik", "Kurang", "Baik", "Baik", "Kurang", "Baik", "Baik"]
    mandi = 0
    disku = 0
    juman = 0
    judis = 0

    if kecerdasan == Mandiri[0]:
        mandi = mandi + 1
    if analisa == Mandiri[1]:
        mandi = mandi + 1
    if kecerdasan_verbal == Mandiri[2]:
        mandi = mandi + 1
    if pengolahan_data_angka == Mandiri[3]:
        mandi = mandi + 1
    if produktivitas_kerja == Mandiri[4]:
        mandi = mandi + 1
    if motivasi_kerja == Mandiri[5]:
        mandi = mandi + 1
    if pengendalian == Mandiri[6]:
        mandi = mandi + 1
    if konsentrasi == Mandiri[7]:
        mandi = mandi + 1
    if stabilitas_emosi == Mandiri[8]:
        mandi = mandi + 1
    if kerja_sama == Mandiri[9]:
        mandi = mandi + 1
    if penyesuaian_diri == Mandiri[10]:
        mandi = mandi + 1
    if kecerdasan == Diskusi[0]:
        disku = disku + 1
    if analisa == Diskusi[1]:
        disku = disku + 1
    if kecerdasan_verbal == Diskusi[2]:
        disku = disku + 1
    if pengolahan_data_angka == Diskusi[3]:
        disku = disku + 1
    if produktivitas_kerja == Diskusi[4]:
        disku = disku + 1
    if motivasi_kerja == Diskusi[5]:
        disku = disku + 1
    if pengendalian == Diskusi[6]:
        disku = disku + 1
    if konsentrasi == Diskusi[7]:
        disku = disku + 1
    if stabilitas_emosi == Diskusi[8]:
        disku = disku + 1
    if kerja_sama == Diskusi[9]:
        disku = disku + 1
    if penyesuaian_diri == Diskusi[10]:
        disku = disku + 1

    juman = mandi/11 * 100
    judis = disku/11 * 100
    return render_template('pass.html', juman=juman, judis=judis, kecerdasan=kecerdasan, daya_tangkap=daya_tangkap,
                           logika_berpikir=logika_berpikir, analisa=analisa,
                           fleksibilitas_berpikir=fleksibilitas_berpikir, kecerdasan_verbal=kecerdasan_verbal,
                           pengolahan_data_angka=pengolahan_data_angka, pemecahan_masalah=pemecahan_masalah,
                           produktivitas_kerja=produktivitas_kerja, motivasi_kerja=motivasi_kerja,
                           perencanaan=perencanaan, pengendalian=pengendalian, daya_tahan_kerja=daya_tahan_kerja,
                           konsentrasi=konsentrasi, inisiatif=inisiatif, stabilitas_emosi=stabilitas_emosi,
                           kerja_sama=kerja_sama, penyesuaian_diri=penyesuaian_diri)

# @app.route('/')
# def nilai():
#     return render_template('baru1.html')
#
# @app.route('/', methods=['post'])
# def getvalue():
#     kecerdasan = request.form['Kecerdasan']
#     daya_tangkap = request.form['Daya Tangkap']
#     logika_berpikir = request.form['Logika Berpikir']
#     analisa = request.form['Analisa']
#     fleksibilitas_berpikir = request.form['Fleksibilitas Berpikir']
#     kecerdasan_verbal = request.form['Kecerdasan Verbal']
#     pengolahan_data_angka = request.form['Pengolahan Data Angka']
#     pemecahan_masalah = request.form['Pemecahan Masalah']
#     produktivitas_kerja = request.form['Produktivitas Kerja']
#     motivasi_kerja = request.form['Motivasi Kerja']
#     perencanaan = request.form['Perencanaan']
#     pengendalian = request.form['Pengendalian']
#     daya_tahan_kerja = request.form['Daya Tahan Kerja']
#     konsentrasi = request.form['Konsentrasi']
#     inisiatif = request.form['Inisiatif']
#     stabilitas_emosi = request.form['Stabilitas Emosi']
#     kerja_sama = request.form['Kerja Sama']
#     penyesuaian_diri = request.form['Penyesuaian Diri']
#
#     if kecerdasan == "6" and fleksibilitas_berpikir == "4" and motivasi_kerja == "4" and pengendalian == "6" \
#             and logika_berpikir == "4" and kecerdasan_verbal == "4" and produktivitas_kerja == "4" \
#             and daya_tahan_kerja == "4" and analisa == "8" and pengolahan_data_angka == "7" \
#             and pemecahan_masalah == "7" and inisiatif == "5":
#         return render_template('pass1.html', hasil="DIII Teknologi Informasi, "
#                                                    "DIV Teknologi Rekayasa Perangkat Lunak"
#                                                    "S1 Teknik Informatika dan S1 Manajemen Rekayasa",
#                                kecerdasan=kecerdasan, daya_tangkap=daya_tangkap, logika_berpikir=logika_berpikir,
#                                analisa=analisa, fleksibilitas_berpikir=fleksibilitas_berpikir,
#                                kecerdasan_verbal=kecerdasan_verbal, pengolahan_data_angka=pengolahan_data_angka,
#                                pemecahan_masalah=pemecahan_masalah, produktivitas_kerja=produktivitas_kerja,
#                                motivasi_kerja=motivasi_kerja, perencanaan=perencanaan, pengendalian=pengendalian,
#                                daya_tahan_kerja=daya_tahan_kerja, konsentrasi=konsentrasi, inisiatif=inisiatif,
#                                stabilitas_emosi=stabilitas_emosi, kerja_sama=kerja_sama,
#                                penyesuaian_diri=penyesuaian_diri)
#
#     elif kecerdasan == "6" and fleksibilitas_berpikir == "4" and motivasi_kerja == "4" and pengendalian == "6" \
#             and analisa == "8" and pengolahan_data_angka == "7" and pemecahan_masalah == "7" and inisiatif == "5":
#         return render_template('pass1.html', hasil="DIII Teknologi Informasi, "
#                                                    "DIV Teknologi Rekayasa Perangkat Lunak "
#                                                    "dan S1 Manajemen Rekayasa", kecerdasan=kecerdasan,
#                                daya_tangkap=daya_tangkap, logika_berpikir=logika_berpikir, analisa=analisa,
#                                fleksibilitas_berpikir=fleksibilitas_berpikir, kecerdasan_verbal=kecerdasan_verbal,
#                                pengolahan_data_angka=pengolahan_data_angka, pemecahan_masalah=pemecahan_masalah,
#                                produktivitas_kerja=produktivitas_kerja, motivasi_kerja=motivasi_kerja,
#                                perencanaan=perencanaan, pengendalian=pengendalian, daya_tahan_kerja=daya_tahan_kerja,
#                                konsentrasi=konsentrasi, inisiatif=inisiatif, stabilitas_emosi=stabilitas_emosi,
#                                kerja_sama=kerja_sama, penyesuaian_diri=penyesuaian_diri)
#
#     elif kecerdasan == "6" and logika_berpikir == "4" and kecerdasan_verbal == "4" and produktivitas_kerja == "4" \
#             and pengendalian == "6" and daya_tahan_kerja == "4" and analisa == "8" \
#             and pengolahan_data_angka == "7" and pemecahan_masalah == "7" and inisiatif == "5":
#         return render_template('pass1.html', hasil="DIII Teknologi Informasi, S1 Informatika "
#                                                    "dan S1 Manajemen Rekayasa", kecerdasan=kecerdasan,
#                                daya_tangkap=daya_tangkap, logika_berpikir=logika_berpikir, analisa=analisa,
#                                fleksibilitas_berpikir=fleksibilitas_berpikir, kecerdasan_verbal=kecerdasan_verbal,
#                                pengolahan_data_angka=pengolahan_data_angka, pemecahan_masalah=pemecahan_masalah,
#                                produktivitas_kerja=produktivitas_kerja, motivasi_kerja=motivasi_kerja,
#                                perencanaan=perencanaan, pengendalian=pengendalian, daya_tahan_kerja=daya_tahan_kerja,
#                                konsentrasi=konsentrasi, inisiatif=inisiatif, stabilitas_emosi=stabilitas_emosi,
#                                kerja_sama=kerja_sama, penyesuaian_diri=penyesuaian_diri)
#
#     elif kecerdasan == "6" and fleksibilitas_berpikir == "4" and motivasi_kerja == "4" and pengendalian == "6" \
#             and logika_berpikir == "4" and kecerdasan_verbal == "4" and produktivitas_kerja == "4" \
#             and daya_tahan_kerja == "4":
#         return render_template('pass1.html', hasil="DIII Teknologi Informasi, "
#                                                    "DIV Teknologi Rekayasa Perangkat Lunak "
#                                                    "dan S1 Teknik Informatika", kecerdasan=kecerdasan,
#                                daya_tangkap=daya_tangkap, logika_berpikir=logika_berpikir, analisa=analisa,
#                                fleksibilitas_berpikir=fleksibilitas_berpikir, kecerdasan_verbal=kecerdasan_verbal,
#                                pengolahan_data_angka=pengolahan_data_angka, pemecahan_masalah=pemecahan_masalah,
#                                produktivitas_kerja=produktivitas_kerja, motivasi_kerja=motivasi_kerja,
#                                perencanaan=perencanaan, pengendalian=pengendalian, daya_tahan_kerja=daya_tahan_kerja,
#                                konsentrasi=konsentrasi, inisiatif=inisiatif, stabilitas_emosi=stabilitas_emosi,
#                                kerja_sama=kerja_sama, penyesuaian_diri=penyesuaian_diri)
#
#     elif fleksibilitas_berpikir == "6" and motivasi_kerja == "9" and logika_berpikir == "4" \
#             and kecerdasan_verbal == "4" and produktivitas_kerja == "4" and daya_tahan_kerja == "4" \
#             and pengendalian == "4":
#         return render_template('pass1.html', hasil="DIV Teknologi Rekayasa Perangkat Lunak, "
#                                                    "S1 Informatika dan S1 Sistem Informasi", kecerdasan=kecerdasan,
#                                daya_tangkap=daya_tangkap, logika_berpikir=logika_berpikir, analisa=analisa,
#                                fleksibilitas_berpikir=fleksibilitas_berpikir, kecerdasan_verbal=kecerdasan_verbal,
#                                pengolahan_data_angka=pengolahan_data_angka, pemecahan_masalah=pemecahan_masalah,
#                                produktivitas_kerja=produktivitas_kerja, motivasi_kerja=motivasi_kerja,
#                                perencanaan=perencanaan, pengendalian=pengendalian, daya_tahan_kerja=daya_tahan_kerja,
#                                konsentrasi=konsentrasi, inisiatif=inisiatif, stabilitas_emosi=stabilitas_emosi,
#                                kerja_sama=kerja_sama, penyesuaian_diri=penyesuaian_diri)
#
#     elif fleksibilitas_berpikir == "6" and motivasi_kerja == "9" and logika_berpikir == "4" \
#             and kecerdasan_verbal == "4" and produktivitas_kerja == "4" and daya_tahan_kerja == "4" \
#             and analisa == "8" and pengolahan_data_angka == "7" and pemecahan_masalah == "7" \
#             and inisiatif == "5":
#         return render_template('pass1.html', hasil="DIV Teknologi Rekayasa Perangkat Lunak, S1 Informatika "
#                                                    "dan S1 Manajemen Rekayasa", kecerdasan=kecerdasan,
#                                daya_tangkap=daya_tangkap, logika_berpikir=logika_berpikir, analisa=analisa,
#                                fleksibilitas_berpikir=fleksibilitas_berpikir, kecerdasan_verbal=kecerdasan_verbal,
#                                pengolahan_data_angka=pengolahan_data_angka, pemecahan_masalah=pemecahan_masalah,
#                                produktivitas_kerja=produktivitas_kerja, motivasi_kerja=motivasi_kerja,
#                                perencanaan=perencanaan, pengendalian=pengendalian, daya_tahan_kerja=daya_tahan_kerja,
#                                konsentrasi=konsentrasi, inisiatif=inisiatif, stabilitas_emosi=stabilitas_emosi,
#                                kerja_sama=kerja_sama, penyesuaian_diri=penyesuaian_diri)
#
#     elif fleksibilitas_berpikir == "6" and motivasi_kerja == "9" and pengendalian == "4" and analisa == "8" \
#             and pengolahan_data_angka == "7" and pemecahan_masalah == "7" and inisiatif == "5":
#         return render_template('pass1.html', hasil="DIV Teknologi Rekayasa Perangkat Lunak, "
#                                                    "S1 Sistem Informasi dan S1 Manajemen Rekayasa",
#                                kecerdasan=kecerdasan, daya_tangkap=daya_tangkap, logika_berpikir=logika_berpikir,
#                                analisa=analisa, fleksibilitas_berpikir=fleksibilitas_berpikir,
#                                kecerdasan_verbal=kecerdasan_verbal, pengolahan_data_angka=pengolahan_data_angka,
#                                pemecahan_masalah=pemecahan_masalah, produktivitas_kerja=produktivitas_kerja,
#                                motivasi_kerja=motivasi_kerja, perencanaan=perencanaan, pengendalian=pengendalian,
#                                daya_tahan_kerja=daya_tahan_kerja, konsentrasi=konsentrasi, inisiatif=inisiatif,
#                                stabilitas_emosi=stabilitas_emosi, kerja_sama=kerja_sama,
#                                penyesuaian_diri=penyesuaian_diri)
#
#     elif fleksibilitas_berpikir == "6" and motivasi_kerja == "9" and daya_tangkap == "6" and perencanaan == "6" \
#             and pengendalian == "7" and daya_tahan_kerja == "6" and konsentrasi == "6" and analisa == "8" \
#             and pengolahan_data_angka == "7" and pemecahan_masalah == "7" and inisiatif == "5":
#         return render_template('pass1.html', hasil="DIV Teknologi Rekayasa Perangkat Lunak,  S1 Teknik Elektro "
#                                                    "dan S1 Manajemen Rekayasa", kecerdasan=kecerdasan,
#                                daya_tangkap=daya_tangkap, logika_berpikir=logika_berpikir, analisa=analisa,
#                                fleksibilitas_berpikir=fleksibilitas_berpikir, kecerdasan_verbal=kecerdasan_verbal,
#                                pengolahan_data_angka=pengolahan_data_angka, pemecahan_masalah=pemecahan_masalah,
#                                produktivitas_kerja=produktivitas_kerja, motivasi_kerja=motivasi_kerja,
#                                perencanaan=perencanaan, pengendalian=pengendalian, daya_tahan_kerja=daya_tahan_kerja,
#                                konsentrasi=konsentrasi, inisiatif=inisiatif, stabilitas_emosi=stabilitas_emosi,
#                                kerja_sama=kerja_sama, penyesuaian_diri=penyesuaian_diri)
#
#     elif analisa == "8" and pengolahan_data_angka == "7" and pemecahan_masalah == "7" and inisiatif == "5" \
#             and logika_berpikir == "4" and kecerdasan_verbal == "4" and produktivitas_kerja == "4" \
#             and daya_tahan_kerja == "4" and pengendalian == "4":
#         return render_template('pass1.html', hasil="S1 Informatika, S1 Sistem Informasi dan S1 Manajemen Rekayasa",
#                                kecerdasan=kecerdasan, daya_tangkap=daya_tangkap, logika_berpikir=logika_berpikir,
#                                analisa=analisa, fleksibilitas_berpikir=fleksibilitas_berpikir,
#                                kecerdasan_verbal=kecerdasan_verbal, pengolahan_data_angka=pengolahan_data_angka,
#                                pemecahan_masalah=pemecahan_masalah, produktivitas_kerja=produktivitas_kerja,
#                                motivasi_kerja=motivasi_kerja, perencanaan=perencanaan, pengendalian=pengendalian,
#                                daya_tahan_kerja=daya_tahan_kerja, konsentrasi=konsentrasi, inisiatif=inisiatif,
#                                stabilitas_emosi=stabilitas_emosi, kerja_sama=kerja_sama,
#                                penyesuaian_diri=penyesuaian_diri)
#
#     elif kecerdasan == "6" and fleksibilitas_berpikir == "4" and motivasi_kerja == "4" and pengendalian == "6":
#         return render_template('pass1.html', hasil="DIII Teknologi Informasi "
#                                                    "dan DIV Teknologi Rekayasa Perangkat Lunak", kecerdasan=kecerdasan,
#                                daya_tangkap=daya_tangkap, logika_berpikir=logika_berpikir, analisa=analisa,
#                                fleksibilitas_berpikir=fleksibilitas_berpikir, kecerdasan_verbal=kecerdasan_verbal,
#                                pengolahan_data_angka=pengolahan_data_angka, pemecahan_masalah=pemecahan_masalah,
#                                produktivitas_kerja=produktivitas_kerja, motivasi_kerja=motivasi_kerja,
#                                perencanaan=perencanaan, pengendalian=pengendalian, daya_tahan_kerja=daya_tahan_kerja,
#                                konsentrasi=konsentrasi, inisiatif=inisiatif, stabilitas_emosi=stabilitas_emosi,
#                                kerja_sama=kerja_sama, penyesuaian_diri=penyesuaian_diri)
#
#     elif kecerdasan == "6" and logika_berpikir == "4" and kecerdasan_verbal == "4" \
#             and produktivitas_kerja == "4" and pengendalian == "6" and daya_tahan_kerja == "4":
#         return render_template('pass1.html', hasil="DIII Teknologi Informasi dan S1 Informatika", kecerdasan=kecerdasan,
#                                daya_tangkap=daya_tangkap, logika_berpikir=logika_berpikir, analisa=analisa,
#                                fleksibilitas_berpikir=fleksibilitas_berpikir, kecerdasan_verbal=kecerdasan_verbal,
#                                pengolahan_data_angka=pengolahan_data_angka, pemecahan_masalah=pemecahan_masalah,
#                                produktivitas_kerja=produktivitas_kerja, motivasi_kerja=motivasi_kerja,
#                                perencanaan=perencanaan, pengendalian=pengendalian, daya_tahan_kerja=daya_tahan_kerja,
#                                konsentrasi=konsentrasi, inisiatif=inisiatif, stabilitas_emosi=stabilitas_emosi,
#                                kerja_sama=kerja_sama, penyesuaian_diri=penyesuaian_diri)
#
#     elif kecerdasan == "6" and pengendalian == "6" and analisa == "8" and pengolahan_data_angka == "7" \
#             and pemecahan_masalah == "7" and inisiatif == "5":
#         return render_template('pass1.html', hasil="DIII Teknologi Informasi dan S1 Manajemen Rekayasa",
#                                kecerdasan=kecerdasan, daya_tangkap=daya_tangkap, logika_berpikir=logika_berpikir,
#                                analisa=analisa, fleksibilitas_berpikir=fleksibilitas_berpikir,
#                                kecerdasan_verbal=kecerdasan_verbal, pengolahan_data_angka=pengolahan_data_angka,
#                                pemecahan_masalah=pemecahan_masalah, produktivitas_kerja=produktivitas_kerja,
#                                motivasi_kerja=motivasi_kerja, perencanaan=perencanaan, pengendalian=pengendalian,
#                                daya_tahan_kerja=daya_tahan_kerja, konsentrasi=konsentrasi, inisiatif=inisiatif,
#                                stabilitas_emosi=stabilitas_emosi, kerja_sama=kerja_sama,
#                                penyesuaian_diri=penyesuaian_diri)
#
#     elif fleksibilitas_berpikir == "6" and motivasi_kerja == "9" and logika_berpikir == "4" \
#             and kecerdasan_verbal == "4" and produktivitas_kerja == "4" and daya_tahan_kerja == "4":
#         return render_template('pass1.html', hasil="DIV Teknologi Rekayasa Perangkat Lunak dan S1 Informatika",
#                                kecerdasan=kecerdasan, daya_tangkap=daya_tangkap, logika_berpikir=logika_berpikir,
#                                analisa=analisa, fleksibilitas_berpikir=fleksibilitas_berpikir,
#                                kecerdasan_verbal=kecerdasan_verbal, pengolahan_data_angka=pengolahan_data_angka,
#                                pemecahan_masalah=pemecahan_masalah, produktivitas_kerja=produktivitas_kerja,
#                                motivasi_kerja=motivasi_kerja, perencanaan=perencanaan, pengendalian=pengendalian,
#                                daya_tahan_kerja=daya_tahan_kerja, konsentrasi=konsentrasi, inisiatif=inisiatif,
#                                stabilitas_emosi=stabilitas_emosi, kerja_sama=kerja_sama,
#                                penyesuaian_diri=penyesuaian_diri)
#
#     elif fleksibilitas_berpikir == "6" and motivasi_kerja == "9" and pengendalian == "4":
#         return render_template('pass1.html', hasil="DIV Teknologi Rekayasa Perangkat Lunak "
#                                                    "dan S1 Sistem Informasi", kecerdasan=kecerdasan,
#                                daya_tangkap=daya_tangkap, logika_berpikir=logika_berpikir, analisa=analisa,
#                                fleksibilitas_berpikir=fleksibilitas_berpikir, kecerdasan_verbal=kecerdasan_verbal,
#                                pengolahan_data_angka=pengolahan_data_angka, pemecahan_masalah=pemecahan_masalah,
#                                produktivitas_kerja=produktivitas_kerja, motivasi_kerja=motivasi_kerja,
#                                perencanaan=perencanaan, pengendalian=pengendalian, daya_tahan_kerja=daya_tahan_kerja,
#                                konsentrasi=konsentrasi, inisiatif=inisiatif, stabilitas_emosi=stabilitas_emosi,
#                                kerja_sama=kerja_sama, penyesuaian_diri=penyesuaian_diri)
#
#     elif fleksibilitas_berpikir == "6" and motivasi_kerja == "9" and daya_tangkap == "6" and perencanaan == "6" \
#             and pengendalian == "7" and daya_tahan_kerja == "6" and konsentrasi == "6":
#         return render_template('pass1.html', hasil="DIV Teknologi Rekayasa Perangkat Lunak dan S1 Teknik Elektro",
#                                kecerdasan=kecerdasan, daya_tangkap=daya_tangkap, logika_berpikir=logika_berpikir,
#                                analisa=analisa, fleksibilitas_berpikir=fleksibilitas_berpikir,
#                                kecerdasan_verbal=kecerdasan_verbal, pengolahan_data_angka=pengolahan_data_angka,
#                                pemecahan_masalah=pemecahan_masalah, produktivitas_kerja=produktivitas_kerja,
#                                motivasi_kerja=motivasi_kerja, perencanaan=perencanaan, pengendalian=pengendalian,
#                                daya_tahan_kerja=daya_tahan_kerja, konsentrasi=konsentrasi, inisiatif=inisiatif,
#                                stabilitas_emosi=stabilitas_emosi, kerja_sama=kerja_sama,
#                                penyesuaian_diri=penyesuaian_diri)
#
#     elif fleksibilitas_berpikir == "6" and motivasi_kerja == "9" and daya_tangkap == "5" and analisa == "5" \
#             and produktivitas_kerja == "7" and pengendalian == "8" and daya_tahan_kerja == "7" \
#             and inisiatif == "7":
#         return render_template('pass1.html', hasil="DIV Teknologi Rekayasa Perangkat Lunak "
#                                                    "dan S1 Teknik Bioproses", kecerdasan=kecerdasan,
#                                daya_tangkap=daya_tangkap, logika_berpikir=logika_berpikir, analisa=analisa,
#                                fleksibilitas_berpikir=fleksibilitas_berpikir, kecerdasan_verbal=kecerdasan_verbal,
#                                pengolahan_data_angka=pengolahan_data_angka, pemecahan_masalah=pemecahan_masalah,
#                                produktivitas_kerja=produktivitas_kerja, motivasi_kerja=motivasi_kerja,
#                                perencanaan=perencanaan, pengendalian=pengendalian, daya_tahan_kerja=daya_tahan_kerja,
#                                konsentrasi=konsentrasi, inisiatif=inisiatif, stabilitas_emosi=stabilitas_emosi,
#                                kerja_sama=kerja_sama, penyesuaian_diri=penyesuaian_diri)
#
#     elif fleksibilitas_berpikir == "6" and motivasi_kerja == "9" and analisa == "8" \
#             and pengolahan_data_angka == "7" and pemecahan_masalah == "7" and inisiatif == "5":
#         return render_template('pass1.html', hasil="DIV Teknologi Rekayasa Perangkat Lunak "
#                                                    "dan S1 Manajemen Rekayasa", kecerdasan=kecerdasan,
#                                daya_tangkap=daya_tangkap, logika_berpikir=logika_berpikir, analisa=analisa,
#                                fleksibilitas_berpikir=fleksibilitas_berpikir, kecerdasan_verbal=kecerdasan_verbal,
#                                pengolahan_data_angka=pengolahan_data_angka, pemecahan_masalah=pemecahan_masalah,
#                                produktivitas_kerja=produktivitas_kerja, motivasi_kerja=motivasi_kerja,
#                                perencanaan=perencanaan, pengendalian=pengendalian, daya_tahan_kerja=daya_tahan_kerja,
#                                konsentrasi=konsentrasi, inisiatif=inisiatif, stabilitas_emosi=stabilitas_emosi,
#                                kerja_sama=kerja_sama, penyesuaian_diri=penyesuaian_diri)
#
#     elif logika_berpikir == "4" and kecerdasan_verbal == "4" and produktivitas_kerja == "4" \
#             and daya_tahan_kerja == "4" and pengendalian == "4":
#         return render_template('pass1.html', hasil="S1 Informatika dan S1 Sistem Informasi", kecerdasan=kecerdasan,
#                                daya_tangkap=daya_tangkap, logika_berpikir=logika_berpikir, analisa=analisa,
#                                fleksibilitas_berpikir=fleksibilitas_berpikir, kecerdasan_verbal=kecerdasan_verbal,
#                                pengolahan_data_angka=pengolahan_data_angka, pemecahan_masalah=pemecahan_masalah,
#                                produktivitas_kerja=produktivitas_kerja, motivasi_kerja=motivasi_kerja,
#                                perencanaan=perencanaan, pengendalian=pengendalian, daya_tahan_kerja=daya_tahan_kerja,
#                                konsentrasi=konsentrasi, inisiatif=inisiatif, stabilitas_emosi=stabilitas_emosi,
#                                kerja_sama=kerja_sama, penyesuaian_diri=penyesuaian_diri)
#
#     elif logika_berpikir == "4" and kecerdasan_verbal == "4" and produktivitas_kerja == "4" \
#             and daya_tahan_kerja == "4" and analisa == "8" and pengolahan_data_angka == "7" \
#             and pemecahan_masalah == "7" and inisiatif == "5":
#         return render_template('pass1.html', hasil="S1 Informatika dan S1 Manajemen Rekayasa", kecerdasan=kecerdasan,
#                                daya_tangkap=daya_tangkap, logika_berpikir=logika_berpikir, analisa=analisa,
#                                fleksibilitas_berpikir=fleksibilitas_berpikir, kecerdasan_verbal=kecerdasan_verbal,
#                                pengolahan_data_angka=pengolahan_data_angka, pemecahan_masalah=pemecahan_masalah,
#                                produktivitas_kerja=produktivitas_kerja, motivasi_kerja=motivasi_kerja,
#                                perencanaan=perencanaan, pengendalian=pengendalian, daya_tahan_kerja=daya_tahan_kerja,
#                                konsentrasi=konsentrasi, inisiatif=inisiatif, stabilitas_emosi=stabilitas_emosi,
#                                kerja_sama=kerja_sama, penyesuaian_diri=penyesuaian_diri)
#
#     elif pengendalian == "4" and analisa == "8" and pengolahan_data_angka == "7" and pemecahan_masalah == "7" \
#             and inisiatif == "5":
#         return render_template('pass1.html', hasil="S1 Sistem Informasi dan S1 Manajemen Rekayasa",
#                                kecerdasan=kecerdasan, daya_tangkap=daya_tangkap, logika_berpikir=logika_berpikir,
#                                analisa=analisa, fleksibilitas_berpikir=fleksibilitas_berpikir,
#                                kecerdasan_verbal=kecerdasan_verbal, pengolahan_data_angka=pengolahan_data_angka,
#                                pemecahan_masalah=pemecahan_masalah, produktivitas_kerja=produktivitas_kerja,
#                                motivasi_kerja=motivasi_kerja, perencanaan=perencanaan, pengendalian=pengendalian,
#                                daya_tahan_kerja=daya_tahan_kerja, konsentrasi=konsentrasi, inisiatif=inisiatif,
#                                stabilitas_emosi=stabilitas_emosi, kerja_sama=kerja_sama,
#                                penyesuaian_diri=penyesuaian_diri)
#
#     elif daya_tangkap == "6" and perencanaan == "6" and pengendalian == "7" and daya_tahan_kerja == "6" \
#             and konsentrasi == "6" and analisa == "8" and pengolahan_data_angka == "7" \
#             and pemecahan_masalah == "7" and inisiatif == "5":
#         return render_template('pass1.html', hasil="S1 Teknik Elektro and S1 Manajemen Rekayasa", kecerdasan=kecerdasan,
#                                daya_tangkap=daya_tangkap, logika_berpikir=logika_berpikir, analisa=analisa,
#                                fleksibilitas_berpikir=fleksibilitas_berpikir, kecerdasan_verbal=kecerdasan_verbal,
#                                pengolahan_data_angka=pengolahan_data_angka, pemecahan_masalah=pemecahan_masalah,
#                                produktivitas_kerja=produktivitas_kerja, motivasi_kerja=motivasi_kerja,
#                                perencanaan=perencanaan, pengendalian=pengendalian, daya_tahan_kerja=daya_tahan_kerja,
#                                konsentrasi=konsentrasi, inisiatif=inisiatif, stabilitas_emosi=stabilitas_emosi,
#                                kerja_sama=kerja_sama, penyesuaian_diri=penyesuaian_diri)
#
#     elif kecerdasan == "6" and pengendalian == "6":
#         return render_template('pass1.html', hasil="DIII Teknologi Informasi", kecerdasan=kecerdasan,
#                                daya_tangkap=daya_tangkap, logika_berpikir=logika_berpikir, analisa=analisa,
#                                fleksibilitas_berpikir=fleksibilitas_berpikir, kecerdasan_verbal=kecerdasan_verbal,
#                                pengolahan_data_angka=pengolahan_data_angka, pemecahan_masalah=pemecahan_masalah,
#                                produktivitas_kerja=produktivitas_kerja, motivasi_kerja=motivasi_kerja,
#                                perencanaan=perencanaan, pengendalian=pengendalian, daya_tahan_kerja=daya_tahan_kerja,
#                                konsentrasi=konsentrasi, inisiatif=inisiatif, stabilitas_emosi=stabilitas_emosi,
#                                kerja_sama=kerja_sama, penyesuaian_diri=penyesuaian_diri)
#
#     elif logika_berpikir == "6" and fleksibilitas_berpikir == "6" and produktivitas_kerja == "9" \
#             and motivasi_kerja == "9" and pengendalian == "9" and daya_tahan_kerja == "8" and inisiatif == "9":
#         return render_template('pass1.html', hasil="DIII Teknologi Komputer", kecerdasan=kecerdasan,
#                                daya_tangkap=daya_tangkap, logika_berpikir=logika_berpikir, analisa=analisa,
#                                fleksibilitas_berpikir=fleksibilitas_berpikir, kecerdasan_verbal=kecerdasan_verbal,
#                                pengolahan_data_angka=pengolahan_data_angka, pemecahan_masalah=pemecahan_masalah,
#                                produktivitas_kerja=produktivitas_kerja, motivasi_kerja=motivasi_kerja,
#                                perencanaan=perencanaan, pengendalian=pengendalian, daya_tahan_kerja=daya_tahan_kerja,
#                                konsentrasi=konsentrasi, inisiatif=inisiatif, stabilitas_emosi=stabilitas_emosi,
#                                kerja_sama=kerja_sama, penyesuaian_diri=penyesuaian_diri)
#
#     elif fleksibilitas_berpikir == "6" and motivasi_kerja == "9":
#         return render_template('pass1.html', hasil="DIV Teknologi Rekayasa Perangkat Lunak", kecerdasan=kecerdasan,
#                                daya_tangkap=daya_tangkap, logika_berpikir=logika_berpikir, analisa=analisa,
#                                fleksibilitas_berpikir=fleksibilitas_berpikir, kecerdasan_verbal=kecerdasan_verbal,
#                                pengolahan_data_angka=pengolahan_data_angka, pemecahan_masalah=pemecahan_masalah,
#                                produktivitas_kerja=produktivitas_kerja, motivasi_kerja=motivasi_kerja,
#                                perencanaan=perencanaan, pengendalian=pengendalian, daya_tahan_kerja=daya_tahan_kerja,
#                                konsentrasi=konsentrasi, inisiatif=inisiatif, stabilitas_emosi=stabilitas_emosi,
#                                kerja_sama=kerja_sama, penyesuaian_diri=penyesuaian_diri)
#
#     elif logika_berpikir == "4" and kecerdasan_verbal == "4" and produktivitas_kerja == "4" \
#             and daya_tahan_kerja == "4":
#         return render_template('pass1.html', hasil="S1 Informatika", kecerdasan=kecerdasan, daya_tangkap=daya_tangkap,
#                                logika_berpikir=logika_berpikir, analisa=analisa,
#                                fleksibilitas_berpikir=fleksibilitas_berpikir, kecerdasan_verbal=kecerdasan_verbal,
#                                pengolahan_data_angka=pengolahan_data_angka, pemecahan_masalah=pemecahan_masalah,
#                                produktivitas_kerja=produktivitas_kerja, motivasi_kerja=motivasi_kerja,
#                                perencanaan=perencanaan, pengendalian=pengendalian, daya_tahan_kerja=daya_tahan_kerja,
#                                konsentrasi=konsentrasi, inisiatif=inisiatif, stabilitas_emosi=stabilitas_emosi,
#                                kerja_sama=kerja_sama, penyesuaian_diri=penyesuaian_diri)
#
#     elif pengendalian == "4":
#         return render_template('pass1.html', hasil="S1 Sistem Informasi", kecerdasan=kecerdasan,
#                                daya_tangkap=daya_tangkap, logika_berpikir=logika_berpikir, analisa=analisa,
#                                fleksibilitas_berpikir=fleksibilitas_berpikir, kecerdasan_verbal=kecerdasan_verbal,
#                                pengolahan_data_angka=pengolahan_data_angka, pemecahan_masalah=pemecahan_masalah,
#                                produktivitas_kerja=produktivitas_kerja, motivasi_kerja=motivasi_kerja,
#                                perencanaan=perencanaan, pengendalian=pengendalian, daya_tahan_kerja=daya_tahan_kerja,
#                                konsentrasi=konsentrasi, inisiatif=inisiatif, stabilitas_emosi=stabilitas_emosi,
#                                kerja_sama=kerja_sama, penyesuaian_diri=penyesuaian_diri)
#
#     elif daya_tangkap == "6" and perencanaan == "6" and pengendalian == "7" and daya_tahan_kerja == "6" \
#             and konsentrasi == "6":
#         return render_template('pass1.html', hasil="S1 Teknik Elektro", kecerdasan=kecerdasan, daya_tangkap=daya_tangkap,
#                                logika_berpikir=logika_berpikir, analisa=analisa,
#                                fleksibilitas_berpikir=fleksibilitas_berpikir, kecerdasan_verbal=kecerdasan_verbal,
#                                pengolahan_data_angka=pengolahan_data_angka, pemecahan_masalah=pemecahan_masalah,
#                                produktivitas_kerja=produktivitas_kerja, motivasi_kerja=motivasi_kerja,
#                                perencanaan=perencanaan, pengendalian=pengendalian, daya_tahan_kerja=daya_tahan_kerja,
#                                konsentrasi=konsentrasi, inisiatif=inisiatif, stabilitas_emosi=stabilitas_emosi,
#                                kerja_sama=kerja_sama, penyesuaian_diri=penyesuaian_diri)
#
#     elif daya_tangkap == "5" and analisa == "5" and produktivitas_kerja == "7" and pengendalian == "8" \
#             and daya_tahan_kerja == "7" and inisiatif == "7":
#         return render_template('pass1.html', hasil="S1 Teknik Bioproses", kecerdasan=kecerdasan,
#                                daya_tangkap=daya_tangkap, logika_berpikir=logika_berpikir, analisa=analisa,
#                                fleksibilitas_berpikir=fleksibilitas_berpikir, kecerdasan_verbal=kecerdasan_verbal,
#                                pengolahan_data_angka=pengolahan_data_angka, pemecahan_masalah=pemecahan_masalah,
#                                produktivitas_kerja=produktivitas_kerja, motivasi_kerja=motivasi_kerja,
#                                perencanaan=perencanaan, pengendalian=pengendalian, daya_tahan_kerja=daya_tahan_kerja,
#                                konsentrasi=konsentrasi, inisiatif=inisiatif, stabilitas_emosi=stabilitas_emosi,
#                                kerja_sama=kerja_sama, penyesuaian_diri=penyesuaian_diri)
#
#     elif analisa == "8" and pengolahan_data_angka == "7" and pemecahan_masalah == "7" and inisiatif == "5":
#         return render_template('pass1.html', hasil="S1 Manajemen Rekayasa", kecerdasan=kecerdasan,
#                                daya_tangkap=daya_tangkap, logika_berpikir=logika_berpikir, analisa=analisa,
#                                fleksibilitas_berpikir=fleksibilitas_berpikir, kecerdasan_verbal=kecerdasan_verbal,
#                                pengolahan_data_angka=pengolahan_data_angka, pemecahan_masalah=pemecahan_masalah,
#                                produktivitas_kerja=produktivitas_kerja, motivasi_kerja=motivasi_kerja,
#                                perencanaan=perencanaan, pengendalian=pengendalian, daya_tahan_kerja=daya_tahan_kerja,
#                                konsentrasi=konsentrasi, inisiatif=inisiatif, stabilitas_emosi=stabilitas_emosi,
#                                kerja_sama=kerja_sama, penyesuaian_diri=penyesuaian_diri)
#
#     else:
#         return render_template('pass1.html', hasil="Tidak Dapat Ditentukan", kecerdasan=kecerdasan,
#                                daya_tangkap=daya_tangkap, logika_berpikir=logika_berpikir, analisa=analisa,
#                                fleksibilitas_berpikir=fleksibilitas_berpikir, kecerdasan_verbal=kecerdasan_verbal,
#                                pengolahan_data_angka=pengolahan_data_angka, pemecahan_masalah=pemecahan_masalah,
#                                produktivitas_kerja=produktivitas_kerja, motivasi_kerja=motivasi_kerja,
#                                perencanaan=perencanaan, pengendalian=pengendalian, daya_tahan_kerja=daya_tahan_kerja,
#                                konsentrasi=konsentrasi, inisiatif=inisiatif, stabilitas_emosi=stabilitas_emosi,
#                                kerja_sama=kerja_sama, penyesuaian_diri=penyesuaian_diri)

@app.route('/home')
def home():
    return render_template('home.html', posts=posts)

@app.route('/about')
def about():
    return render_template('about.html', title='About')

class pengguna(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    kecerdasan = db.Column(db.String(6), nullable=False)
    analisa = db.Column(db.String(6), nullable=False)
    kecerdasan_verbal = db.Column(db.String(6), nullable=False)
    pengolahan_data_angka = db.Column(db.String(6), nullable=False)
    produktivitas_kerja = db.Column(db.String(6), nullable=False)
    motivasi_kerja = db.Column(db.String(6), nullable=False)
    pengendalian = db.Column(db.String(6), nullable=False)
    konsentrasi = db.Column(db.String(6), nullable=False)
    stabilitas_emosi = db.Column(db.String(6), nullable=False)
    kerja_sama = db.Column(db.String(6), nullable=False)
    penyesuaian_diri = db.Column(db.String(6), nullable=False)

    def __repr__(self):
        return f"User('{self.kecerdasan}', '{self.analisa}', '{self.kecerdasan_verbal}', '{self.pengolahan_data_angka}', '{self.produktivitas_kerja}', '{self.motivasi_kerja}', '{self.pengendalian}', '{self.konsentrasi}', '{self.stabilitas_emosi}', '{self.kerja_sama}', '{self.penyesuaian_diri}')"

@app.route("/<user>")
def index(user=None):
    return render_template("user.html", user=user)

@app.route('/send', methods=['GET', 'POST'])
def send():
    if request.method == 'POST':
        age = request.form['age']
        if request.form['age'] < 18:
            return render_template('age.html', age="belum cukup umur")
        else:
            return render_template('age.html', age=age)
    return render_template('index.html')

@app.route("/shopping")
def shopping():
    food = ["Cheese", "Tuna", "Beef", "Toothpaste"]
    return render_template("shopping.html", food=food)

@app.route("/mahasiswa", methods=['GET', 'POST'])
def mahasiswa():
    Mandiri = 0
    Diskusi = 0
    form = mahasiswaform()
    if form.validate_on_submit():
        if form.kecerdasan.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.analisa.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.kecerdasan_verbal.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.pengolahan_data_angka.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.produktivitas_kerja.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.motivasi_kerja.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.pengendalian.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.konsentrasi.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.stabilitas_emosi.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.kerja_sama.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.penyesuaian_diri.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        bobot_mandiri = Mandiri/11 * 100
        bobot_diskusi = Diskusi/11 * 100

        final_bobot_mandiri = "Mandiri = " + str(bobot_mandiri) + " %"
        final_bobot_diskusi = "Diskusi = " + str(bobot_diskusi) + " %"

        if request.method == 'POST':
            final_bobot_mandiri = request.form['final_bobot_mandiri']
            final_bobot_diskusi = request.form['final_bobot_diskusi']

            return redirect(url_for('metodebelajar.html', title="Metode Belajar", final_bobot_mandiri=final_bobot_mandiri, final_bobot_diskusi=final_bobot_diskusi))

    return render_template('mhs.html', title="mahasiswa", form=form)

if __name__ == "__main__":
    app.run(debug=True)