from flask import Flask, render_template, url_for, redirect, request
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from form import mahasiswaform

app = Flask(__name__)
app.config['SECRET_KEY'] = '870f94cd87f840f55e7c9e81ba1d6bba'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///maha.db'
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)

posts = [
    {
        'author': 'Corey Schafer',
        'title': 'Blog Post 1',
        'content': 'First post content',
        'date posted': 'April 20, 2018'
    },
    {
        'author': 'Jane Doe',
        'title': 'Blog Post 2',
        'content': 'Second post content',
        'date posted': 'April 21, 2018'
    }
]

@app.route('/')
@app.route('/')
def baru():
    return render_template('baru.html')

@app.route('/', methods=['post'])
def getvalue():
    kecerdasan = request.form['Kecerdasan']
    daya_tangkap = request.form['Daya Tangkap']
    logika_berpikir = request.form['Logika Berpikir']
    analisa = request.form['Analisa']
    fleksibilitas_berpikir = request.form['Fleksibilitas Berpikir']
    kecerdasan_verbal = request.form['Kecerdasan Verbal']
    pengolahan_data_angka = request.form['Pengolahan Data Angka']
    pemecahan_masalah = request.form['Pemecahan Masalah']
    produktivitas_kerja = request.form['Produktivitas Kerja']
    motivasi_kerja = request.form['Motivasi Kerja']
    perencanaan = request.form['Perencanaan']
    pengendalian = request.form['Pengendalian']
    daya_tahan_kerja = request.form['Daya Tahan Kerja']
    konsentrasi = request.form['Konsentrasi']
    inisiatif = request.form['Inisiatif']
    stabilitas_emosi = request.form['Stabilitas Emosi']
    kerja_sama = request.form['Kerja Sama']
    penyesuaian_diri = request.form['Penyesuaian Diri']

    Mandiri = ["baik", "baik", "kurang", "baik", "kurang", "baik", "kurang", "kurang", "baik", "kurang", "kurang"]
    Diskusi = ["kurang", "kurang", "baik", "kurang", "baik", "kurang", "baik", "baik", "kurang", "baik", "baik"]
    mandi = 0
    disku = 0
    juman = 0
    judis = 0

    if kecerdasan == Mandiri[0]:
        mandi = mandi + 1
    if analisa == Mandiri[1]:
        mandi = mandi + 1
    if kecerdasan_verbal == Mandiri[2]:
        mandi = mandi + 1
    if pengolahan_data_angka == Mandiri[3]:
        mandi = mandi + 1
    if produktivitas_kerja == Mandiri[4]:
        mandi = mandi + 1
    if motivasi_kerja == Mandiri[5]:
        mandi = mandi + 1
    if pengendalian == Mandiri[6]:
        mandi = mandi + 1
    if konsentrasi == Mandiri[7]:
        mandi = mandi + 1
    if stabilitas_emosi == Mandiri[8]:
        mandi = mandi + 1
    if kerja_sama == Mandiri[9]:
        mandi = mandi + 1
    if penyesuaian_diri == Mandiri[10]:
        mandi = mandi + 1
    if kecerdasan == Diskusi[0]:
        disku = disku + 1
    if analisa == Diskusi[1]:
        disku = disku + 1
    if kecerdasan_verbal == Diskusi[2]:
        disku = disku + 1
    if pengolahan_data_angka == Diskusi[3]:
        disku = disku + 1
    if produktivitas_kerja == Diskusi[4]:
        disku = disku + 1
    if motivasi_kerja == Diskusi[5]:
        disku = disku + 1
    if pengendalian == Diskusi[6]:
        disku = disku + 1
    if konsentrasi == Diskusi[7]:
        disku = disku + 1
    if stabilitas_emosi == Diskusi[8]:
        disku = disku + 1
    if kerja_sama == Diskusi[9]:
        disku = disku + 1
    if penyesuaian_diri == Diskusi[10]:
        disku = disku + 1

    juman = mandi/11 * 100
    judis = disku/11 * 100
    return render_template('pass.html', juman=juman, judis=judis)

@app.route('/home')
def home():
    return render_template('home.html', posts=posts)

@app.route('/about')
def about():
    return render_template('about.html', title='About')

class pengguna(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    kecerdasan = db.Column(db.String(6), nullable=False)
    analisa = db.Column(db.String(6), nullable=False)
    kecerdasan_verbal = db.Column(db.String(6), nullable=False)
    pengolahan_data_angka = db.Column(db.String(6), nullable=False)
    produktivitas_kerja = db.Column(db.String(6), nullable=False)
    motivasi_kerja = db.Column(db.String(6), nullable=False)
    pengendalian = db.Column(db.String(6), nullable=False)
    konsentrasi = db.Column(db.String(6), nullable=False)
    stabilitas_emosi = db.Column(db.String(6), nullable=False)
    kerja_sama = db.Column(db.String(6), nullable=False)
    penyesuaian_diri = db.Column(db.String(6), nullable=False)

    def __repr__(self):
        return f"User('{self.kecerdasan}', '{self.analisa}', '{self.kecerdasan_verbal}', '{self.pengolahan_data_angka}', '{self.produktivitas_kerja}', '{self.motivasi_kerja}', '{self.pengendalian}', '{self.konsentrasi}', '{self.stabilitas_emosi}', '{self.kerja_sama}', '{self.penyesuaian_diri}')"

@app.route("/<user>")
def index(user=None):
    return render_template("user.html", user=user)

@app.route('/send', methods=['GET', 'POST'])
def send():
    if request.method == 'POST':
        age = request.form['age']
        if request.form['age'] < 18:
            return render_template('age.html', age="belum cukup umur")
        else:
            return render_template('age.html', age=age)
    return render_template('index.html')

@app.route("/shopping")
def shopping():
    food = ["Cheese", "Tuna", "Beef", "Toothpaste"]
    return render_template("shopping.html", food=food)

@app.route("/mahasiswa", methods=['GET', 'POST'])
def mahasiswa():
    Mandiri = 0
    Diskusi = 0
    form = mahasiswaform()
    if form.validate_on_submit():
        if form.kecerdasan.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.analisa.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.kecerdasan_verbal.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.pengolahan_data_angka.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.produktivitas_kerja.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.motivasi_kerja.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.pengendalian.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.konsentrasi.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.stabilitas_emosi.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.kerja_sama.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        if form.penyesuaian_diri.data == 'Baik':
            Mandiri = Mandiri + 1
        else:
            Diskusi = Diskusi + 1

        bobot_mandiri = Mandiri/11 * 100
        bobot_diskusi = Diskusi/11 * 100

        final_bobot_mandiri = "Mandiri = " + str(bobot_mandiri) + " %"
        final_bobot_diskusi = "Diskusi = " + str(bobot_diskusi) + " %"

        if request.method == 'POST':
            final_bobot_mandiri = request.form['final_bobot_mandiri']
            final_bobot_diskusi = request.form['final_bobot_diskusi']

            return redirect(url_for('metodebelajar.html', title="Metode Belajar", final_bobot_mandiri=final_bobot_mandiri, final_bobot_diskusi=final_bobot_diskusi))

    return render_template('mhs.html', title="mahasiswa", form=form)

if __name__ == "__main__":
    app.run(debug=True)