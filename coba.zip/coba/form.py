from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, RadioField
from wtforms.validators import DataRequired, Length

class mahasiswaform(FlaskForm):
    kecerdasan = StringField('Kecerdasan',
                             validators=[DataRequired(), Length(min=4, max=6)])
    analisa = StringField('Analisa',
                             validators=[DataRequired(), Length(min=4, max=6)])
    kecerdasan_verbal = StringField('Kecerdasan Verbal',
                             validators=[DataRequired(), Length(min=4, max=6)])
    pengolahan_data_angka = StringField('Pengolahan Data Angka',
                             validators=[DataRequired(), Length(min=4, max=6)])
    produktivitas_kerja = StringField('Produktivitas Kerja',
                             validators=[DataRequired(), Length(min=4, max=6)])
    motivasi_kerja = StringField('Motivasi Kerja',
                             validators=[DataRequired(), Length(min=4, max=6)])
    pengendalian = StringField('Pengendalian',
                             validators=[DataRequired(), Length(min=4, max=6)])
    konsentrasi= StringField('Konsentrasi',
                             validators=[DataRequired(), Length(min=4, max=6)])
    stabilitas_emosi= StringField('Stabilitas Emosi',
                             validators=[DataRequired(), Length(min=4, max=6)])
    kerja_sama= StringField('Kerja Sama',
                             validators=[DataRequired(), Length(min=4, max=6)])
    penyesuaian_diri= StringField('Penyesuaian Diri',
                             validators=[DataRequired(), Length(min=4, max=6)])
    submit = SubmitField('Submit')